This directory contains module based .tpl.php files and theme includes.
